# CalisVerse - Revolutionary 3D Calisthenics E-commerce Platform

## Overview
CalisVerse is a cutting-edge 3D e-commerce website specializing in calisthenics equipment, designed specifically for the Arabic market. It features an immersive Three.js-powered shopping experience with IKEA-style guided journeys.

## Features

### 🎯 Core Features
- **3D Interactive Shopping**: Immersive WebGL-powered product visualization
- **Arabic-First Design**: Complete RTL support with proper Arabic typography
- **Guided Journey System**: IKEA-inspired personalized shopping paths
- **Adaptive Performance**: Automatic graphics quality adjustment
- **Mobile-First Responsive**: Optimized for all devices

### 🛍️ E-commerce Functionality
- Interactive 3D product viewer with rotation and zoom
- Real-time color customization
- Smart shopping cart with persistent storage
- User experience level detection (Beginner/Intermediate/Professional)
- Personalized product recommendations

### 🎨 Design System
- **Color Scheme**: White background, black text, lilac (#8B5CF6) accents
- **Typography**: Noto Sans Arabic font family
- **Animations**: GSAP-powered smooth transitions (200-500ms)
- **Framework**: Tailwind CSS with RTL support

### 🔧 Technical Stack
- **Frontend**: HTML5, Tailwind CSS, JavaScript ES6+
- **3D Engine**: Three.js with WebGL
- **Animations**: GSAP (GreenSock)
- **Fonts**: Google Fonts (Noto Sans Arabic)
- **Storage**: LocalStorage for cart persistence

## Getting Started

### Prerequisites
- Modern web browser with WebGL support
- Internet connection for CDN resources

### Installation
1. Clone or download the project files
2. Open `index.html` in a web browser
3. Or serve using a local server:
   ```bash
   npx serve .
   ```

### Project Structure
```
CalisVerse/
├── index.html              # Main HTML file
├── css/
│   └── styles.css         # Custom CSS styles
├── js/
│   └── main.js           # Main JavaScript application
├── assets/
│   ├── models/           # 3D model files (future)
│   └── textures/         # Texture files (future)
└── package.json          # Project configuration
```

## Features Implementation

### 🎮 3D Product Viewer
- Interactive pull-up bar model created with Three.js primitives
- Orbit controls for rotation and zoom
- Professional lighting setup with shadows
- Automatic rotation animation
- Reset view functionality

### 🛒 Shopping Cart
- Slide-out sidebar interface
- Add/remove items functionality
- Quantity management
- Price calculation
- Persistent storage across sessions

### 🎯 User Journey System
- Experience level modal (Beginner/Intermediate/Professional)
- Personalized product recommendations
- Guided navigation through product catalog
- Cultural adaptation for Middle Eastern market

### 📱 Responsive Design
- Mobile-first approach
- Adaptive 3D viewport
- Touch-friendly controls
- Optimized for Arabic RTL layout

## Browser Support
- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

## Performance Optimizations
- Progressive loading with visual feedback
- Efficient 3D rendering with requestAnimationFrame
- Optimized asset loading
- Responsive image handling

## Future Enhancements
- GLTF model loading for realistic products
- Augmented Reality (AR) integration
- Advanced product customization
- Payment gateway integration
- User account system
- Multi-language support
- Advanced analytics tracking

## Arabic Market Considerations
- Right-to-left (RTL) layout support
- Arabic typography and font rendering
- Cultural color preferences
- Local payment methods integration
- Regional shipping options
- Arabic customer support

## Development Notes
- All text content is in Arabic
- Proper RTL spacing and layout
- Cultural sensitivity in design choices
- Performance optimized for various device capabilities
- Accessibility considerations for Arabic users

## License
MIT License - Feel free to use and modify for your projects.

## Contact
For questions or support, please contact the CalisVerse development team.

---
Built with ❤️ for the Arabic calisthenics community
