# 3D Models Directory

This directory contains the 3D models for CalisVerse products.

## Required Files:
- pullup-black.glb
- pullup-walnut.glb  
- pullup-steel.glb
- rings-black.glb
- rings-walnut.glb
- rings-steel.glb
- parallettes-black.glb
- parallettes-walnut.glb
- parallettes-steel.glb

## Fallback Files:
- pullup.glb (default)
- rings.glb (default)
- parallettes.glb (default)

Note: These are placeholder files. Replace with actual 3D models in production.
